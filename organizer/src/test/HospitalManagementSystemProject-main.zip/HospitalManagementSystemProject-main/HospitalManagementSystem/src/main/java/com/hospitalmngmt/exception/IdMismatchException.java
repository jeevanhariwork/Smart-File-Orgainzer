package com.hospitalmngmt.exception;

public class IdMismatchException extends Exception
{
	public IdMismatchException(String msg) {
		super(msg);
	}
}
