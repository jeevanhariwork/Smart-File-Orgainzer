package com.hospitalmngmt.exception;

public class PrescriptionNotValidException extends Exception
{
	public PrescriptionNotValidException(String msg) {
		super(msg);
	}
}
